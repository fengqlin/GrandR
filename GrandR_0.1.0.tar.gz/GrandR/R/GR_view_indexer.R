#' @title Grandma's Research Panorama Indexer (Project Command Center)
#' @description Core Logic: Modification time fingerprinting + Instant cache loading.
#' Scans 'possessdata' to generate a visual timeline of all research runs.
#' @tag Vault / Dashboard
#'
#' @param base_dir Path to the data archive, defaults to "possessdata".
#' @param force_refresh Boolean; if TRUE, forces a full re-scan.
#'
#' @importFrom dplyr %>% bind_rows arrange desc select mutate across where
#' @importFrom reactable reactable colDef colFormat reactableTheme
#' @importFrom htmltools div h1 hr span tags browsable
#' @importFrom tidyr as_tibble
#' @importFrom tibble rownames_to_column
#' @importFrom base64enc base64encode
#' @importFrom utils capture.output
#'
#' @export
GR_view_indexer <- function(base_dir = "possessdata", force_refresh = FALSE) {

  # --- 1. Environment & Path Check ---
  if (!dir.exists(base_dir)) {
    stop(paste0("Archive error: The folder '", base_dir, "' could not be found. Please check the path."))
  }

  # --- 2. Smart Fingerprint Comparison ---
  run_dirs <- list.dirs(base_dir, recursive = FALSE, full.names = TRUE)
  run_dirs <- run_dirs[grepl("Run_", run_dirs)]

  if (length(run_dirs) == 0) {
    message("📋 No run records found in '", base_dir, "'.")
    return(invisible(NULL))
  }

  # Digital fingerprint (based on paths, mtime, and size)
  current_fingerprint <- file.info(run_dirs) %>%
    dplyr::select(mtime, size) %>%
    tibble::rownames_to_column("path")

  cache_file <- file.path(base_dir, ".GR_index_cache.rds")

  # Check for valid cache
  if (!force_refresh && file.exists(cache_file)) {
    cache_data <- tryCatch(readRDS(cache_file), error = function(e) NULL)
    if (!is.null(cache_data) && identical(cache_data$fingerprint, current_fingerprint)) {
      cat("⚡ Smart Index: No changes detected. Opening snapshot instantly...\n")
      return(htmltools::browsable(cache_data$html))
    }
  }

  cat("🛰️  Scanning research panorama: Sampling data and generating visual gallery...\n")

  # --- 3. Deep Data Extraction ---
  index_data_list <- lapply(run_dirs, function(d) {
    f_name <- basename(d)
    parts <- strsplit(f_name, "_")[[1]]

    # A. Metadata Extraction
    ts <- parts[2]
    tm <- parts[3]
    formatted_ts <- paste0(substr(ts,1,4), "-", substr(ts,5,6), "-", substr(ts,7,8), " ",
                           substr(tm,1,2), ":", substr(tm,3,4))

    exp_label <- if (length(parts) >= 4) paste(parts[4:length(parts)], collapse = "_") else "Untitled_Analysis"
    is_final <- grepl("FINAL", f_name, ignore.case = TRUE) || file.exists(file.path(d, "FINAL.txt"))

    # B. Visual Gallery
    png_files <- list.files(d, pattern = "\\.png$", full.names = TRUE, recursive = TRUE)
    img_list <- list()
    if (length(png_files) > 0) {
      max_imgs <- min(length(png_files), 5)
      for(i in 1:max_imgs) {
        img_raw <- readBin(png_files[i], "raw", file.info(png_files[i])$size)
        img_list[[i]] <- paste0("data:image/png;base64,", base64enc::base64encode(img_raw))
      }
    }

    # C. Data Sampling (3x3 Golden Logic)
    rds_path <- list.files(d, pattern = "\\.rds$", full.names = TRUE)[1]
    sample_content <- "N/A"
    if (!is.na(rds_path) && file.exists(rds_path)) {
      res <- tryCatch(readRDS(rds_path), error = function(e) NULL)
      if (!is.null(res)) {
        target <- if(is.data.frame(res)) res else if(is.list(res)) {
          dfs <- Filter(is.data.frame, res); if(length(dfs)>0) dfs[[1]] else NULL
        } else NULL

        if (!is.null(target) && nrow(target) > 0) {
          mini <- target[1:min(3, nrow(target)), 1:min(3, ncol(target)), drop = FALSE] %>%
            dplyr::mutate(dplyr::across(dplyr::where(is.numeric), ~ signif(., 3)))
          sample_content <- utils::capture.output(print(mini, row.names = FALSE)) %>% paste(collapse = "\n")
        }
      }
    }

    # D. Storage Stats
    all_files <- list.files(d, recursive = TRUE, full.names = TRUE)
    folder_size_mb <- round(sum(file.info(all_files)$size) / (1024^2), 2)
    file_manifest <- data.frame(
      FileName = basename(all_files),
      Size_KB = round(file.info(all_files)$size/1024, 1),
      stringsAsFactors = FALSE
    )

    # E. Audit Health Check
    abs_path <- normalizePath(d, winslash = "/")
    report_file <- file.path(d, "Analysis_Audit_Report.html")
    report_abs <- if(file.exists(report_file)) normalizePath(report_file, winslash = "/") else NA

    health_status <- "N/A"
    if (!is.na(report_abs)) {
      txt <- readLines(report_file, n = 100, warn = FALSE)
      health_status <- "✅ Clean"
      if (any(grepl("Warning|警告", txt))) health_status <- "⚠️ Warning"
      if (any(grepl("Error|错误", txt))) health_status <- "❌ Error"
    }

    data.frame(
      Time = formatted_ts, Label = exp_label, Star = if(is_final) "⭐" else "⚪",
      Health = health_status, Size_MB = folder_size_mb,
      Sample = sample_content, ReportPath = report_abs,
      FolderPath = abs_path,
      stringsAsFactors = FALSE
    ) %>% dplyr::mutate(Preview = list(img_list), Manifest = list(file_manifest))
  })

  full_df <- dplyr::bind_rows(index_data_list) %>%
    dplyr::arrange(dplyr::desc(Star), dplyr::desc(Time))

  # --- 4. Build Interactive UI ---
  total_size <- sum(full_df$Size_MB)

  tbl <- reactable::reactable(
    full_df, searchable = TRUE, sortable = TRUE, pagination = TRUE,
    highlight = TRUE, striped = TRUE,
    theme = reactable::reactableTheme(
      style = list(fontSize = "15px"),
      headerStyle = list(backgroundColor = "#1e293b", color = "white", fontSize = "16px")
    ),
    columns = list(
      Time = reactable::colDef(name = "Run Time", width = 170),
      Star = reactable::colDef(name = "Rank", width = 70, align = "center",
                               style = function(v) list(color = if(v == "⭐") "#f59e0b" else "#cbd5e1")),
      Label = reactable::colDef(name = "Task Label", minWidth = 200, style = list(fontWeight = "bold", color = "#0f172a")),
      Preview = reactable::colDef(name = "Gallery", minWidth = 250, cell = function(v) {
        if(length(v)==0) htmltools::span(style="color:#cbd5e1; font-style:italic;","No preview")
        else htmltools::div(style="display:flex; gap:8px; overflow-x:auto; padding:5px;",
                            lapply(v, function(i) htmltools::tags$img(src=i, height="60px", style="border-radius:4px; flex-shrink:0; border:1px solid #e2e8f0;")))
      }),
      Sample = reactable::colDef(name = "Data Snapshot (3x3)", minWidth = 220, cell = function(v) {
        if(v=="N/A") "N/A"
        else htmltools::tags$pre(style="font-size:11px; background:#f8fafc; padding:8px; margin:0; line-height:1.2; color:#475569; border:1px solid #e2e8f0;", v)
      }),
      Health = reactable::colDef(name = "Audit", width = 100, align = "center", cell = function(value, index) {
        path <- full_df$ReportPath[index]
        if (is.na(path)) htmltools::span(style="color:#cbd5e1;", value)
        else htmltools::tags$a(href = paste0("file:///", path), target = "_blank",
                               style="font-weight:bold; color:#3b82f6; text-decoration:none;", value)
      }),
      FolderPath = reactable::colDef(show = FALSE),
      Size_MB = reactable::colDef(name = "Size", width = 100, format = reactable::colFormat(suffix = " MB")),
      ReportPath = reactable::colDef(show = FALSE),
      Manifest = reactable::colDef(show = FALSE)
    ),

    # 💥 Expanded Details Panel (Fixed for Experiment Manifest)
    details = function(index) {
      row_data <- full_df[index, ]
      manifest_df <- row_data$Manifest[[1]]

      htmltools::div(
        style = "padding: 20px; background: #f8fafc; border-left: 4px solid #3b82f6;",

        htmltools::h4("📁 Experiment File Manifest", style="margin-top:0; color:#1e293b;"),

        # Render File List
        reactable::reactable(
          manifest_df,
          compact = TRUE,
          columns = list(
            FileName = reactable::colDef(name = "File Name", style=list(fontFamily="monospace", fontSize="13px")),
            Size_KB = reactable::colDef(name = "Size", width = 100, format = reactable::colFormat(suffix = " KB"))
          ),
          theme = reactable::reactableTheme(style = list(backgroundColor = "transparent"))
        ),

        htmltools::div(
          style = "margin-top: 15px; font-size: 13px; color: #64748b;",
          htmltools::tags$b("Location: "), htmltools::span(style="font-family:monospace;", row_data$FolderPath)
        )
      )
    }
  )

  # --- 5. Assemble HTML ---
  html_page <- htmltools::div(
    style = "padding: 40px; background: #ffffff; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;",
    htmltools::h1("👵 Grandma's Research Panorama Index", style = "color: #0f172a; font-weight: 800; margin-bottom: 5px;"),
    htmltools::div(style = "display: flex; justify-content: space-between; color: #64748b; font-size: 14px; margin-bottom: 20px;",
                   htmltools::span("📘 Smart Mode: Instant load active."),
                   htmltools::span(paste0("📊 Stats: ", length(run_dirs), " Runs | ", round(total_size, 2), " MB Total"))),
    htmltools::hr(style = "border: 0; border-top: 1px solid #e2e8f0; margin-bottom: 25px;"),
    tbl
  )

  saveRDS(list(fingerprint = current_fingerprint, html = html_page), cache_file)
  return(htmltools::browsable(html_page))
}

