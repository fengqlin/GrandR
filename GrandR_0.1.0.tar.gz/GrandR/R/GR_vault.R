#' @title GrandR Vault Ingestor (High-Speed Parquet Writer)
#' @description Core Logic: Auto type-casting (List -> Tidy DF) + Memory profiling + >1GB auto-chunking.
#' Transforms R objects into highly compressed, queryable Parquet assets.
#' @tag IO / Vault
#'
#' @param data The R object to ingest (data.frame or list).
#' @param asset_name A unique identifier for this data asset.
#' @param vault_dir Path to the reference vault. Defaults to "data/processed".
#' @param chunk_threshold_mb Memory threshold (MB) to trigger auto-chunking. Defaults to 1024 (1GB).
#'
#' @importFrom dplyr tibble bind_rows
#' @importFrom arrow write_parquet write_dataset
#' @importFrom lobstr obj_size
#' @importFrom utils stack
#'
#' @export
#' @examples
#' \dontrun{
#' # Ingest a clinical dataframe
#' GR_io_write(data = my_clinical_df, asset_name = "Cohort_A_Clinical")
#'
#' # Ingest a gene set list (automatically flattens to Tidy format)
#' GR_io_write(data = my_pathways_list, asset_name = "MSigDB_Hallmark")
#' }
GR_io_write <- function(data, asset_name, vault_dir = "data/processed", chunk_threshold_mb = 1024) {

  # --- 1. Vault Initialization ---
  if (!dir.exists(vault_dir)) {
    dir.create(vault_dir, recursive = TRUE)
    cat("📁 Initializing Vault at:", normalizePath(vault_dir), "\n")
  }

  safe_name <- gsub("[^[:alnum:]_]", "_", asset_name)
  cat("🛡️  Ingesting asset: [", safe_name, "]\n")

  # --- 2. Type Detection & Flattening (List -> Tidy DF) ---
  if (is.list(data) && !is.data.frame(data)) {
    cat("🧩 Detected List object. Flattening to Tidy DataFrame...\n")
    if (is.null(names(data))) names(data) <- paste0("Set_", seq_along(data))

    clean_data <- tryCatch({
      dplyr::tibble(utils::stack(data))[, c(2, 1)]
    }, error = function(e) stop("Failed to flatten list. Ensure it contains atomic vectors."))

    colnames(clean_data) <- c("Term", "Value")
    data <- clean_data
  } else if (!is.data.frame(data)) {
    stop("Unsupported data type. Please provide a data.frame or a named list.")
  }

  data <- as.data.frame(data)

  # --- 3. Memory Profiling ---
  mem_bytes <- as.numeric(lobstr::obj_size(data))
  mem_mb <- mem_bytes / (1024^2)
  cat(sprintf("⚖️  Memory Profile: %.2f MB\n", mem_mb))

  meta_info <- list(
    Asset_Name = safe_name,
    Original_Class = if(exists("clean_data")) "List" else "DataFrame",
    Rows = nrow(data),
    Cols = ncol(data),
    Size_MB = round(mem_mb, 2),
    Ingest_Time = Sys.time()
  )

  # --- 4. The Parquet Engine (Chunking Logic) ---
  if (mem_mb > chunk_threshold_mb) {
    cat("🔥 Large dataset detected. Triggering Auto-Chunking Dataset...\n")
    asset_dir <- file.path(vault_dir, paste0(safe_name, "_chunked.parquet"))
    if (dir.exists(asset_dir)) unlink(asset_dir, recursive = TRUE)

    arrow::write_dataset(dataset = data, path = asset_dir, format = "parquet", max_rows_per_file = 2000000)
    meta_info$Format <- "Chunked_Parquet_Dir"
    meta_info$Path <- asset_dir
  } else {
    cat("⚡ High-speed Parquet compression active...\n")
    asset_file <- file.path(vault_dir, paste0(safe_name, ".parquet"))
    arrow::write_parquet(data, asset_file)
    meta_info$Format <- "Single_Parquet_File"
    meta_info$Path <- asset_file
  }

  # --- 5. Save Metadata ---
  saveRDS(meta_info, file.path(vault_dir, paste0(safe_name, "_meta.rds")))
  cat("✅ Asset [", safe_name, "] successfully archived to vault.\n")
  return(invisible(meta_info))
}


#' @title GrandR Vault Extractor (Smart Data Reader)
#' @description Automatically routes and loads Parquet assets. Supports Out-of-Memory (Lazy) loading for massive datasets.
#' @tag IO / Vault
#'
#' @param asset_name Name of the asset to pull.
#' @param vault_dir Path to the vault. Defaults to "data/processed".
#' @param as_arrow_query Boolean; if TRUE, returns an Arrow query for lazy evaluation.
#'
#' @importFrom arrow read_parquet open_dataset
#' @importFrom dplyr collect
#' @export
GR_io_read <- function(asset_name, vault_dir = "data/processed", as_arrow_query = FALSE) {

  if (!dir.exists(vault_dir)) stop("Vault directory not found.")

  safe_name <- gsub("[^[:alnum:]_]", "_", asset_name)
  meta_file <- file.path(vault_dir, paste0(safe_name, "_meta.rds"))

  if (!file.exists(meta_file)) stop("Asset metadata not found: ", safe_name)

  meta_info <- readRDS(meta_file)
  asset_path <- meta_info$Path

  cat("📥 Loading Asset: [", safe_name, "] (", meta_info$Format, ")\n")

  if (meta_info$Format == "Single_Parquet_File") {
    if (as_arrow_query) return(arrow::open_dataset(asset_path, format = "parquet"))
    return(arrow::read_parquet(asset_path))
  } else {
    arrow_ds <- arrow::open_dataset(asset_path, format = "parquet")
    if (as_arrow_query) return(arrow_ds)
    cat("⚠️  Warning: Pulling large chunked dataset into RAM.\n")
    return(dplyr::collect(arrow_ds))
  }
}


#' @title GrandR Data Vault Radar (Asset Inventory)
#' @description Interactive dashboard to scan and manage Parquet assets within the vault.
#' @tag Vault / Explorer
#'
#' @param vault_dir Path to the vault. Defaults to "data/processed".
#' @importFrom dplyr tibble arrange desc mutate
#' @importFrom reactable reactable colDef reactableTheme
#' @importFrom htmltools div h1 hr span tags browsable
#' @export
GR_view_vault <- function(vault_dir = "data/processed") {

  if (!dir.exists(vault_dir)) {
    # Auto-detect if user used old "RefVault" name
    if (dir.exists("RefVault")) vault_dir <- "RefVault" else return(message("📁 Vault is empty."))
  }

  meta_files <- list.files(vault_dir, pattern = "_meta\\.rds$", full.names = TRUE)
  if (length(meta_files) == 0) return(message("📭 No registered assets found."))

  meta_list <- lapply(meta_files, function(f) {
    res <- tryCatch(readRDS(f), error = function(e) NULL)
    if (is.list(res)) {
      data.frame(Asset = res$Asset_Name, Class = res$Original_Class, Rows = res$Rows,
                 Cols = res$Cols, Size_MB = res$Size_MB, Format = res$Format,
                 Ingest_Time = format(res$Ingest_Time, "%Y-%m-%d %H:%M"), stringsAsFactors = FALSE)
    }
  })

  vault_df <- do.call(rbind, meta_list) %>% dplyr::tibble() %>% dplyr::arrange(dplyr::desc(Ingest_Time))

  tbl <- reactable::reactable(
    vault_df, searchable = TRUE, sortable = TRUE,
    theme = reactable::reactableTheme(
      headerStyle = list(backgroundColor = "#0f172a", color = "white")
    ),
    columns = list(
      Asset = reactable::colDef(name = "Asset Name", style = list(fontWeight = "bold", color = "#2563eb", fontFamily = "monospace")),
      Class = reactable::colDef(name = "Type", width = 120, align = "center", cell = function(v) {
        color <- if(v == "List") "#d946ef" else "#0ea5e9"
        htmltools::span(style = paste0("background:", color, "20; color:", color, "; padding:4px 8px; border-radius:12px; font-weight:bold; font-size:12px;"), v)
      }),
      Rows = reactable::colDef(format = reactable::colFormat(separators = TRUE)),
      Size_MB = reactable::colDef(name = "Size", format = reactable::colFormat(suffix = " MB")),
      Format = reactable::colDef(show = FALSE)
    ),
    details = function(index) {
      row_data <- vault_df[index, ]
      # 💡 Note: Using standardized 'GR_io_read' in the generated code
      load_code <- sprintf("# Load to RAM:\ndata <- GR_io_read('%s')\n\n# Lazy Load (OOM):\nlazy <- GR_io_read('%s', as_arrow_query = TRUE)",
                           row_data$Asset, row_data$Asset)

      htmltools::div(
        style = "padding: 20px; background: #f8fafc; border-left: 4px solid #f59e0b;",
        htmltools::div(style = "font-size: 13px; font-weight: bold; margin-bottom: 5px;", "💻 Quick Load Snippet:"),
        htmltools::tags$pre(style = "font-size: 12px; background: #1e293b; color: #e2e8f0; padding: 15px; border-radius: 6px; font-family: monospace;", load_code)
      )
    }
  )

  html_page <- htmltools::div(
    style = "padding: 40px; background: #ffffff; font-family: sans-serif;",
    htmltools::h1("👵 GrandR Data Vault Radar", style = "color: #0f172a; font-weight: 800;"),
    htmltools::div(style = "color: #64748b; font-size: 14px; margin-bottom: 20px;",
                   htmltools::span(paste0("📊 Vault Inventory: ", nrow(vault_df), " Assets Registered."))),
    htmltools::hr(style = "border: 0; border-top: 1px solid #e2e8f0; margin-bottom: 25px;"),
    tbl
  )
  return(htmltools::browsable(html_page))
}

