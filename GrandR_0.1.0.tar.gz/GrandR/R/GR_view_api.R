#' @title GrandR API Asset Explorer (Standardized Documentation UI)
#' @description Core Logic: UI Dashboard + Auto Markdown + Dependency Sniffer + Examples Extraction.
#' Scans R scripts for Roxygen2 tags to build an interactive function catalog.
#' @tag Dashboard / Explorer
#'
#' @param func_dir Path to the directory containing function scripts. Defaults to "scripts/functions".
#' @param export_md Boolean; if TRUE, auto-generates 'API_Reference.md'.
#'
#' @importFrom dplyr tibble arrange desc mutate
#' @importFrom reactable reactable colDef reactableTheme
#' @importFrom htmltools div h1 hr span tags browsable HTML
#' @importFrom magrittr %<>%
#'
#' @export
#' @examples
#' \dontrun{
#' # Scan the project's standardized function directory
#' GR_view_api(func_dir = "scripts/functions")
#' }
GR_view_api <- function(func_dir = "scripts/functions", export_md = TRUE) {

  # --- 1. Target Directory Scanning ---
  if (!dir.exists(func_dir)) {
    # If the default standardized path doesn't exist, try the old "function" folder
    if(func_dir == "scripts/functions" && dir.exists("function")) {
      func_dir <- "function"
    } else {
      stop(paste0("Directory error: The folder '", func_dir, "' could not be found."))
    }
  }

  target_files <- list.files(func_dir, pattern = "\\.[Rr]$", full.names = TRUE)

  if (length(target_files) == 0) {
    message("📋 No .R scripts were found in the '", func_dir, "' directory.")
    return(invisible(NULL))
  }

  cat("🔍 Target acquired: Scanning all", length(target_files), "scripts in the '", func_dir, "' directory...\n")

  # --- 2. Advanced Roxygen Parsing Engine ---
  func_registry <- list()

  for (file_path in target_files) {
    lines <- readLines(file_path, warn = FALSE)
    file_name <- basename(file_path)

    title_indices <- grep("^#'\\s+@title", lines)

    if (length(title_indices) > 0) {
      for (i in title_indices) {
        # Scope the block
        search_limit <- min(i + 100, length(lines))
        block_lines <- lines[(i + 1):search_limit]

        # Metadata extraction
        title_text <- trimws(sub("^#'\\s+@title", "", lines[i]))
        desc_match <- grep("^#'\\s+@description", block_lines)
        desc_text  <- if(length(desc_match) > 0) trimws(sub("^#'\\s+@description", "", block_lines[desc_match[1]])) else "N/A"
        tag_match  <- grep("^#'\\s+@tag", block_lines)
        tag_text   <- if(length(tag_match) > 0) trimws(sub("^#'\\s+@tag", "", block_lines[tag_match[1]])) else "Untagged"
        func_match <- grep("^[A-Za-z0-9_.]+\\s*(<-|=)\\s*function", block_lines)
        func_name  <- if(length(func_match) > 0) trimws(strsplit(block_lines[func_match[1]], "(<-|=)\\s*function")[[1]][1]) else "Unknown_Function"

        is_exported <- length(grep("^#'\\s+@export", block_lines)) > 0
        visibility  <- ifelse(is_exported, "Public", "Private")

        return_line <- grep("^#'\\s+@return", block_lines, value = TRUE)
        return_text <- if(length(return_line) > 0) trimws(sub("^#'\\s+@return", "", return_line[1])) else "No return value specified."

        # Dependency Sniffer
        import_lines <- grep("^#'\\s+@importFrom", block_lines, value = TRUE)
        if (length(import_lines) > 0) {
          pkgs <- sapply(strsplit(import_lines, "\\s+"), function(x) if(length(x)>=3) x[3] else NA)
          deps_text <- paste(unique(pkgs[!is.na(pkgs)]), collapse = ", ")
        } else {
          deps_text <- "Base R"
        }

        # Examples Extraction
        example_start <- grep("^#'\\s+@examples", block_lines)
        examples_text <- "No examples provided."
        if (length(example_start) > 0) {
          ex_start_idx <- example_start[1] + 1
          ex_end_idx   <- length(block_lines)
          for (k in ex_start_idx:length(block_lines)) {
            if (grepl("^#'\\s+@[a-zA-Z]", block_lines[k])) { ex_end_idx <- k - 1; break }
          }
          if (ex_start_idx <= ex_end_idx) {
            ex_lines <- block_lines[ex_start_idx:ex_end_idx]
            examples_text <- trimws(paste(sub("^#'\\s?", "", ex_lines), collapse = "\n"), which = "right")
          }
        }

        # Source Code Snippet
        snippet_limit <- if(length(func_match) > 0) func_match[1] + 5 else 10
        raw_snippet <- paste(lines[i:(i + snippet_limit)], collapse = "\n")

        func_registry[[length(func_registry) + 1]] <- data.frame(
          File = file_name, Function = func_name, Visibility = visibility,
          Tag = tag_text, Title = title_text, Description = desc_text,
          Returns = return_text, Examples = examples_text,
          Dependencies = deps_text, Snippet = raw_snippet, stringsAsFactors = FALSE
        )
      }
    }
  }

  if (length(func_registry) == 0) return(invisible(NULL))
  final_df <- do.call(rbind, func_registry) %>% dplyr::tibble() %>% dplyr::arrange(desc(Visibility), File)

  # --- 3. Optional: Export to Markdown ---
  if (export_md) {
    md_content <- c("# 📚 GrandR API Asset Reference\n",
                    paste("> Auto-generated on:", Sys.time(), "\n\n---\n"))
    for (idx in 1:nrow(final_df)) {
      row <- final_df[idx, ]
      badge <- ifelse(row$Visibility == "Public", "🟢 **[Public]**", "🔒 **[Private]**")
      md_content <- c(md_content, paste("##", row$Function), paste(badge, " | 🏷️ Tag:", row$Tag, "| 📦 Deps:", row$Dependencies, "\n"),
                      paste("**Description**: ", row$Description, "\n"), paste("### 📤 Returns\n", row$Returns, "\n"))
      if (row$Examples != "No examples provided.") md_content <- c(md_content, "### 💡 Example Usage\n```r\n", row$Examples, "\n```\n")
      md_content <- c(md_content, "---\n")
    }
    writeLines(md_content, "API_Reference.md")
    cat("✅ Markdown API reference updated: 'API_Reference.md'\n")
  }

  # --- 4. Build Interactive UI ---
  tbl <- reactable::reactable(
    final_df, searchable = TRUE, sortable = TRUE, pagination = TRUE,
    theme = reactable::reactableTheme(
      style = list(fontSize = "15px"),
      headerStyle = list(backgroundColor = "#0f172a", color = "white", fontSize = "16px")
    ),
    columns = list(
      Visibility = reactable::colDef(name = "Access", width = 100, align = "center", cell = function(value) {
        color <- if(value == "Public") "#10b981" else "#94a3b8"
        htmltools::span(style = paste0("background:", color, "20; color:", color, "; padding:4px 8px; border-radius:4px; font-size:12px; font-weight:bold;"), value)
      }),
      File = reactable::colDef(name = "Source File", width = 150, style = list(color = "#64748b", fontFamily = "monospace", fontSize = "13px")),
      Function = reactable::colDef(name = "Function Name", width = 220, style = list(fontWeight = "bold", color = "#2563eb", fontFamily = "monospace")),
      Tag = reactable::colDef(name = "Tag", width = 140, align = "center", cell = function(value) {
        htmltools::span(style = "background:#0ea5e920; color:#0ea5e9; padding:4px 8px; border-radius:12px; font-size:12px; font-weight:bold;", value)
      }),
      Title = reactable::colDef(name = "Title", minWidth = 200, style = list(fontWeight = "600")),
      Description = reactable::colDef(show = FALSE), Returns = reactable::colDef(show = FALSE),
      Examples = reactable::colDef(show = FALSE), Dependencies = reactable::colDef(show = FALSE), Snippet = reactable::colDef(show = FALSE)
    ),
    details = function(index) {
      row_data <- final_df[index, ]
      returns_ui <- if (row_data$Returns == "No return value specified.") {
        htmltools::div(style = "color: #94a3b8; font-style: italic;", row_data$Returns)
      } else {
        htmltools::div(style = "font-size: 13px; color: #334155;", row_data$Returns)
      }
      examples_ui <- if (row_data$Examples != "No examples provided.") {
        htmltools::div(style = "margin-top: 15px;",
                       htmltools::div(style = "color: #0f172a; font-weight: bold; font-size: 13px; border-bottom: 1px solid #cbd5e1;", "💡 Example Usage:"),
                       htmltools::tags$pre(style = "font-size: 13px; background: #f1f5f9; padding: 15px; border-radius: 6px; font-family: monospace; overflow-x: auto;", row_data$Examples))
      } else htmltools::div()

      htmltools::div(
        style = "padding: 20px; background: #f8fafc; border-left: 4px solid #3b82f6; display: grid; gap: 15px;",
        htmltools::div(style = "font-size: 14px; color: #475569;",
                       htmltools::span(style = "font-weight: bold; color: #0f172a;", "📝 Description: "), row_data$Description, htmltools::br(),
                       htmltools::span(style = "font-weight: bold; color: #0f172a;", "📦 Dependencies: "), htmltools::span(style="font-family: monospace; color: #d946ef;", row_data$Dependencies)),
        htmltools::div(style = "color: #0f172a; font-weight: bold; font-size: 13px; border-bottom: 1px solid #cbd5e1;", "📤 Returns:"),
        returns_ui, examples_ui,
        htmltools::div(style = "color: #0f172a; font-weight: bold; font-size: 13px;", "💻 Source Header:"),
        htmltools::tags$pre(style = "font-size: 12px; background: #1e293b; color: #e2e8f0; padding: 12px; border-radius: 6px; font-family: monospace; overflow-x: auto;", row_data$Snippet)
      )
    }
  )

  # --- 5. Assemble Final HTML ---
  html_page <- htmltools::div(
    style = "padding: 40px; background: #ffffff; font-family: sans-serif;",
    htmltools::h1("👵 GrandR API Asset Dashboard", style = "color: #0f172a; font-weight: 800;"),
    htmltools::div(style = "color: #64748b; font-size: 14px; margin-bottom: 20px;",
                   htmltools::span(paste0("📊 ", nrow(final_df), " functions scanned from [", func_dir, "]."))),
    htmltools::hr(style = "border: 0; border-top: 1px solid #e2e8f0; margin-bottom: 25px;"),
    tbl
  )
  return(htmltools::browsable(html_page))
}
