#' @title Grandma's Multi-Theme Palette Vault (Standardized)
#' @description Manages isolated color themes in R's global options to ensure visual consistency across different figures.
#' @tag Palette / Visualization
#'
#' @param ... Named character vectors of hex codes (e.g., Mutant = "#E64B35").
#' @param theme_id The isolated namespace for this palette. Defaults to "Default".
#' @param preset Load a premium journal preset ("Nature", "Lancet", "JAMA").
#' @param save_local Boolean; if TRUE, saves all themes to 'GR_palette_config.rds'.
#'
#' @export
#' @examples
#' \dontrun{
#' library(ggplot2)
#' library(patchwork)
#'
#' # Step 1: Initialize themes using the standardized 'GR_pal_set'
#' GR_pal_set(PIM1_Mut = "#E64B35", PIM1_WT = "#4DBBD5", theme_id = "Molecular")
#' GR_pal_set(CR = "#E18727", PR = "#20854E", theme_id = "Clinical")
#'
#' # Step 2: Extract colors using 'GR_pal_get'
#' p1 <- ggplot(mtcars, aes(factor(cyl), fill = factor(cyl))) +
#'   geom_bar() +
#'   scale_fill_manual(values = GR_pal_get(c("4", "6", "8"), theme_id = "Molecular"))
#'
#' GR_pal_show()
#' }
GR_pal_set <- function(..., theme_id = "Default", preset = NULL, save_local = FALSE) {

  presets <- list(
    Nature = c("#E64B35", "#4DBBD5", "#00A087", "#3C5488", "#F39B7F", "#8491B4", "#91D1C2", "#DC0000"),
    Lancet = c("#00468B", "#ED0000", "#42B540", "#0099B4", "#925E9F", "#FDAF91", "#AD002A", "#ADB6B6"),
    JAMA   = c("#374E55", "#DF8F44", "#00A1D5", "#B24745", "#79AF97", "#6A6599", "#80796B")
  )

  new_colors <- list()
  if (!is.null(preset) && preset %in% names(presets)) {
    preset_cols <- presets[[preset]]
    names(preset_cols) <- paste0("Color_", 1:length(preset_cols))
    new_colors <- as.list(preset_cols)
  }

  custom_colors <- list(...)
  if (length(custom_colors) > 0) {
    if (length(custom_colors) == 1 && is.vector(custom_colors[[1]]) && !is.null(names(custom_colors[[1]]))) {
      custom_colors <- as.list(custom_colors[[1]])
    }
    new_colors <- modifyList(new_colors, custom_colors)
  }

  if (length(new_colors) == 0) return(invisible(NULL))

  all_themes <- getOption("GrandR.palettes", list())

  if (!is.null(all_themes[[theme_id]])) {
    all_themes[[theme_id]] <- modifyList(all_themes[[theme_id]], new_colors)
  } else {
    all_themes[[theme_id]] <- new_colors
  }

  options(GrandR.palettes = all_themes)
  cat(sprintf("🎨 Palette Theme [%s] updated! (%d colors total)\n", theme_id, length(all_themes[[theme_id]])))

  if (save_local) {
    saveRDS(all_themes, "GR_palette_config.rds")
    cat("💾 All palette themes archived to 'GR_palette_config.rds'.\n")
  }

  return(invisible(all_themes[[theme_id]]))
}


#' @title Grandma's Theme-Aware Color Extractor (Standardized)
#' @description Retrieves hex codes from a specific theme namespace.
#' @tag Palette / Visualization
#'
#' @param groups Character vector of group names.
#' @param theme_id The theme namespace to pull from. Defaults to "Default".
#' @param fallback The hex color for missing groups. Defaults to "#CCCCCC".
#' @export
GR_pal_get <- function(groups, theme_id = "Default", fallback = "#CCCCCC") {

  all_themes <- getOption("GrandR.palettes")

  if (is.null(all_themes) && file.exists("GR_palette_config.rds")) {
    all_themes <- readRDS("GR_palette_config.rds")
    options(GrandR.palettes = all_themes)
  }

  if (is.null(all_themes) || is.null(all_themes[[theme_id]])) {
    warning(sprintf("Theme [%s] not found. Fallback triggered.", theme_id))
    res <- rep(fallback, length(groups))
    names(res) <- groups
    return(res)
  }

  target_pal <- all_themes[[theme_id]]
  matched_colors <- unlist(target_pal[groups])

  missing_idx <- is.na(matched_colors)
  if (any(missing_idx)) {
    warning(sprintf("[%s] Missing groups in theme '%s': %s.",
                    Sys.time(), theme_id, paste(groups[missing_idx], collapse = ", ")))
    matched_colors[missing_idx] <- fallback
  }

  names(matched_colors) <- groups
  return(matched_colors)
}


#' @title Grandma's Palette Visualizer (Standardized)
#' @description Generates a sleek swatch grid of all active global palettes.
#' @tag Palette / Visualization
#'
#' @export
GR_pal_show <- function() {

  all_themes <- getOption("GrandR.palettes")

  if (is.null(all_themes)) {
    if (file.exists("GR_palette_config.rds")) {
      all_themes <- readRDS("GR_palette_config.rds")
      options(GrandR.palettes = all_themes)
    } else {
      stop("Global palettes are empty. Run GR_pal_set() first.")
    }
  }

  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("Package 'ggplot2' required for visualization.")
  }

  df_list <- lapply(names(all_themes), function(theme_name) {
    pal <- all_themes[[theme_name]]
    data.frame(
      Theme = theme_name,
      Name = names(pal),
      Hex = as.character(pal),
      stringsAsFactors = FALSE
    )
  })

  df <- do.call(rbind, df_list)
  df$Name <- factor(df$Name, levels = rev(unique(df$Name)))

  p <- ggplot2::ggplot(df, ggplot2::aes(x = Theme, y = Name, fill = Hex)) +
    ggplot2::geom_tile(color = "white", linewidth = 1) +
    ggplot2::geom_text(ggplot2::aes(label = paste(Name, "-", Hex)),
                       color = ifelse(col2rgb(df$Hex)[1,] + col2rgb(df$Hex)[2,] + col2rgb(df$Hex)[3,] < 382, "white", "black"),
                       fontface = "bold", size = 4) +
    ggplot2::scale_fill_identity() +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold", size = 16, hjust = 0.5, margin = ggplot2::margin(b = 15)),
      axis.text.x = ggplot2::element_text(face = "bold", size = 12, color = "#1e293b"),
      axis.title = ggplot2::element_blank(),
      panel.grid = ggplot2::element_blank()
    ) +
    ggplot2::labs(title = "🎨 GrandR Multi-Theme Palette Swatch")

  print(p)
  return(invisible(p))
}
