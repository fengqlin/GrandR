#' @title GrandR Research Recorder (Standard Analytical Audit Trail)
#' @description Core Logic: Precision trajectory tracking + Auto-pipeline caching +
#' Resource monitoring + Multi-omics data audit + Visual report generation.
#' @tag Research / Tracker
#'
#' @param func The target function to execute.
#' @param ... Arguments passed to the target function.
#' @param note Task label or note, defaults to "Analysis".
#' @param base_dir Path to the data archive, defaults to "possessdata".
#' @param force_run Boolean; whether to force execution and bypass cache, defaults to FALSE.
#'
#' @importFrom digest digest
#' @importFrom gt gt tab_header tab_options as_raw_html
#' @importFrom htmltools htmlEscape
#' @importFrom base64enc dataURI
#' @importFrom tibble rownames_to_column
#' @importFrom utils capture.output sessionInfo
#' @importFrom grDevices png dev.off
#'
#' @export
GR_run_recorder <- function(func, ..., note = "Analysis", base_dir = "possessdata", force_run = FALSE) {

  # --- 1. [Identity] Task Fingerprinting & Cache Check ---
  raw_func_name  <- deparse(substitute(func))
  func_code      <- tryCatch({ paste(deparse(func), collapse = "\n") }, error = function(e) { "Code unknown" })
  args_list      <- list(...)
  # Fingerprint includes code, arguments, and note for perfect reproducibility
  args_md5       <- digest::digest(list(func_code, args_list, note), algo = "md5")

  if(!dir.exists(base_dir)) dir.create(base_dir)
  cache_file <- file.path(base_dir, paste0("Cache_", args_md5, ".rds"))

  # --- 2. [Smart Cache] Steward Logic ---
  cat("\n", rep("━", 60), "\n")
  cat("🆔 Task Hash: ", args_md5, "\n")
  if (!force_run && file.exists(cache_file)) {
    cat("🛡️  Smart Steward: Identical task detected. Extracting from cache...\n")
    cat("📅 Archive Date: ", format(file.info(cache_file)$mtime, "%Y-%m-%d %H:%M:%S"), "\n")
    cat(rep("━", 60), "\n\n")
    return(readRDS(cache_file))
  }

  # --- 3. [Isolation] Create Run Directory ---
  start_time <- Sys.time()
  ver_id     <- format(start_time, "%Y%m%d_%H%M%S")
  safe_note  <- gsub("[^[:alnum:]_]", "_", note)
  run_folder <- paste0("Run_", ver_id, "_", safe_note)
  run_dir    <- file.path(base_dir, run_folder)
  dir.create(run_dir, showWarnings = FALSE, recursive = TRUE)

  cat("🚀 Task Launched: ", note, "\n📂 Exp Directory: ", normalizePath(run_dir), "\n")

  # --- 4. [Pre-run Snapshot] ---
  get_clean_file_list <- function() {
    all_f <- list.files(getwd(), full.names = TRUE, recursive = TRUE)
    # Exclude archive and temp directories
    clean_f <- all_f[!grepl(paste0("/", base_dir, "/|\\.Rproj\\.user"), all_f)]
    return(clean_f)
  }
  files_before <- get_clean_file_list()

  # --- 5. [Data Audit Helpers] ---
  get_df_audit_gt <- function(df, title = "Data Audit") {
    if (!is.data.frame(df)) return("")
    nr <- nrow(df); nc <- ncol(df); n_row_show <- min(nr, 20); n_col_show <- min(nc, 20)
    audit_gt <- data.frame(Column = colnames(df)[1:n_col_show], Type = sapply(df[1:n_col_show], function(x) class(x)[1])) %>%
      gt::gt() %>% gt::tab_header(title = title, subtitle = paste0("Dimension: ", nr, "x", nc)) %>% gt::tab_options(table.font.size = "10px")
    snapshot_gt <- df[1:n_row_show, 1:n_col_show, drop = FALSE] %>% as.data.frame() %>% tibble::rownames_to_column("Row_Index") %>%
      gt::gt() %>% gt::tab_header(title = "Top 20x20 Snapshot") %>% gt::tab_options(table.font.size = "10px")
    return(paste0("<div class='audit-box' style='margin-bottom:20px;'>", gt::as_raw_html(audit_gt), gt::as_raw_html(snapshot_gt), "</div>"))
  }

  input_audit_html <- ""; output_audit_html <- ""; md5_report_html <- ""
  df_inputs <- Filter(is.data.frame, args_list)
  if(length(df_inputs) > 0) {
    md5_items <- sapply(names(df_inputs), function(nm) paste0("<li><b>", nm, "</b>: <code>", digest::digest(df_inputs[[nm]], algo = "md5"), "</code></li>"))
    md5_report_html <- paste0("<div class='section-card'><div class='section-title'>🔐 Input MD5 Checksums</div><ul>", paste(md5_items, collapse=""), "</ul></div>")
    input_audit_html <- paste(sapply(names(df_inputs), function(nm) get_df_audit_gt(df_inputs[[nm]], paste("📥 Input Data:", nm))), collapse = "")
  }

  # --- 6. [Execution & Monitoring] ---
  cat("⚙️  Mounting performance monitors and log collectors...\n")
  mem_start <- gc()[2, 6]; cpu_start <- proc.time()
  is_error <- FALSE; error_msg <- NULL

  internal_logs <- utils::capture.output({
    result <- tryCatch({ func(...) }, error = function(e) { is_error <<- TRUE; error_msg <<- e$message; return(e) })
  })

  cpu_end <- proc.time() - cpu_start; runtime <- round(cpu_end["elapsed"], 2)
  peak_mem <- max(gc()[2, 6] - mem_start, 0) + gc()[2, 6]

  # --- 7. [Gallery Processing] ---
  preview_gallery_html <- ""
  if (!is_error) {
    extract_plots <- function(obj) {
      classes <- c("ggplot", "gg", "Heatmap", "HeatmapList", "grob", "gtable", "patchwork", "recordedplot")
      if (inherits(obj, classes)) return(list(obj))
      if (is.list(obj) && !is.data.frame(obj)) { inner <- lapply(obj, extract_plots); return(do.call(c, inner)) }
      return(NULL)
    }
    found_plots <- extract_plots(result)
    if (length(found_plots) > 0) {
      preview_gallery_html <- "<div class='gallery-container'>"
      for (i in seq_along(found_plots)) {
        p_path <- file.path(run_dir, paste0("Figure_", i, ".png"))
        grDevices::png(p_path, width=1200, height=1000, res=150)
        curr_p <- found_plots[[i]]
        if (inherits(curr_p, c("Heatmap", "HeatmapList"))) {
          if(requireNamespace("ComplexHeatmap", quietly = TRUE)) ComplexHeatmap::draw(curr_p)
        } else if (inherits(curr_p, "grob")) {
          grid::grid.newpage(); grid::grid.draw(curr_p)
        } else { print(curr_p) }
        grDevices::dev.off()
        preview_gallery_html <- paste0(preview_gallery_html, "<div class='gallery-card'><h5>Figure ", i, "</h5><img src='", base64enc::dataURI(file=p_path, mime="image/png"), "'></div>")
      }
      preview_gallery_html <- paste0(preview_gallery_html, "</div>")
    }
    if(is.data.frame(result)) output_audit_html <- get_df_audit_gt(result, "📤 Output Data Audit")
  }

  # --- 8. [Scraping Attachments] ---
  files_after <- get_clean_file_list()
  new_candidates <- setdiff(files_after, files_before)
  captured_links <- ""
  if (length(new_candidates) > 0) {
    actual_new <- new_candidates[file.info(new_candidates)$mtime >= (start_time - 2)]
    target_files <- actual_new[grepl("\\.(xlsx|pdf|png|csv|txt|tiff|Rdata|jpeg|svg)$", actual_new, ignore.case = TRUE)]
    if (length(target_files) > 0) {
      for (f in target_files) {
        file.copy(f, file.path(run_dir, basename(f)), overwrite = TRUE)
        captured_links <- paste0(captured_links, "<li><a href='./", basename(f), "' target='_blank'>📎 ", basename(f), "</a></li>")
      }
    }
  }

  # --- 9. [HTML Construction] ---
  sess_info <- utils::capture.output(utils::sessionInfo())
  methodology_text <- paste0("Research audit was conducted via GR_run_recorder. Task integrity hash: ", args_md5, ". Stats: ", runtime, "s, ", round(peak_mem, 2), "MB peak.")

  html_content <- paste0(
    "<html><head><meta charset='utf-8'><link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism-tomorrow.min.css'>",
    "<style>",
    "body{font-family:'Segoe UI',system-ui,sans-serif; background:#f1f5f9; color:#0f172a; padding:40px; line-height:1.6;} ",
    ".header-bar{background:linear-gradient(135deg, #1e293b 0%, #334155 100%); color:white; padding:30px; border-radius:12px; margin-bottom:30px; box-shadow:0 10px 15px -3px rgba(0,0,0,0.1);} ",
    ".section-card{background:white; padding:25px; border-radius:12px; margin-bottom:25px; border:1px solid #e2e8f0; box-shadow:0 1px 3px rgba(0,0,0,0.05);} ",
    ".section-title{font-size:18px; font-weight:800; color:#1e293b; margin-bottom:15px; border-left:5px solid #3b82f6; padding-left:15px;} ",
    ".terminal-box{background:#0f172a; color:#38bdf8; padding:20px; border-radius:8px; font-family:monospace; font-size:13px; overflow-x:auto;} ",
    ".gallery-container{display:grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap:20px;} ",
    ".gallery-card{background:#f8fafc; border:1px solid #e2e8f0; padding:15px; border-radius:8px; text-align:center;} .gallery-card img{max-width:100%; border-radius:4px;} ",
    ".methods-snippet{background:#eff6ff; color:#1e40af; border:1px dashed #3b82f6; padding:15px; font-size:14px; border-radius:8px;} ",
    "</style></head><body>",
    "<div class='header-bar'><h1>🔬 GrandR Research Audit Trail</h1><p><b>Hash:</b> ", args_md5, " | <b>Note:</b> ", note, " | <b>Executed:</b> ", ver_id, "</p></div>",
    "<div class='section-card'><div class='section-title'>📝 Methodology Snippet</div><div class='methods-snippet'>", methodology_text, "</div></div>",
    "<div class='section-card'><div class='section-title'>📊 Performance Monitor</div><ul><li><b>Elapsed Time:</b> ", runtime, "s</li><li><b>Peak Memory:</b> ", round(peak_mem, 2), " MB</li></ul></div>",
    if(is_error) paste0("<div class='section-card' style='border-left:10px solid #ef4444;'><div class='section-title' style='color:#ef4444;'>❌ Error Report</div><pre style='color:#ef4444; background:#fef2f2; padding:15px;'>", htmltools::htmlEscape(error_msg), "</pre></div>") else "",
    "<div class='section-card'><div class='section-title'>📋 Console Logs</div><div class='terminal-box'>", paste(htmltools::htmlEscape(internal_logs), collapse="<br>"), "</div></div>",
    md5_report_html,
    "<div class='section-card'><div class='section-title'>🖼️ Figure Gallery</div>", preview_gallery_html, "</div>",
    if(captured_links != "") paste0("<div class='section-card'><div class='section-title'>📂 Attachments</div><ul>", captured_links, "</ul></div>") else "",
    "<div class='section-card'><div class='section-title'>📜 Source Code</div><pre class='language-r'><code class='language-r'>", htmltools::htmlEscape(func_code), "</code></pre></div>",
    "<div class='section-card'><div class='section-title'>📥 Data Audit</div>", input_audit_html, output_audit_html, "</div>",
    "<div class='section-card'><div class='section-title'>💻 Session Information</div><pre style='font-size:11px; color:#64748b;'>", paste(htmltools::htmlEscape(sess_info), collapse="\n"), "</pre></div>",
    "<script src='https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js'></script><script src='https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-r.min.js'></script></body></html>"
  )

  writeLines(html_content, file.path(run_dir, "Analysis_Audit_Report.html"))
  if(!is_error) { saveRDS(result, cache_file); saveRDS(result, file.path(run_dir, "Result_Object.rds")) }
  cat(rep("━", 60), "\n✅ [Report Generated]: ", normalizePath(file.path(run_dir, "Analysis_Audit_Report.html")), "\n")
  return(result)
}
