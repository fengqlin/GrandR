#' @title GrandR Project Scaffold (Standard Research Workspace)
#' @description Automatically initializes a standardized directory structure for research projects.
#' Supports built-in preset schemes or full customization via character vectors.
#' @tag Project / Infrastructure
#'
#' @param project_name Path to the project directory. Defaults to the current working directory.
#' @param structure Directory layout. Choose from "standard" (default), "minimal", or provide a custom character vector.
#' @param author Name of the lead researcher/author to be included in the init.R header.
#'
#' @export
GR_scaffold <- function(project_name = NULL, structure = "standard", author = "Linfeng") {

  # --- 1. Preset Scheme Definitions ---
  preset_schemes <- list(
    # [Standard] Full-cycle Bioinformatics Research Protocol
    standard = c(
      "data/raw",          # Unprocessed raw files (Read-only)
      "data/processed",    # Processed data (Parquet/RDS)
      "scripts/pipeline",  # Core analytical workflows (e.g., 01_cleaning.R)
      "scripts/functions", # Project-specific local helper functions
      "figures/raw",       # Directly generated R plots
      "figures/final",     # Publication-ready figures
      "results/tables",    # Exported statistical summaries
      "possessdata"        # ⬅️ [Crucial] Archive for GR_run_recorder audits and caches
    ),
    # [Minimal] Lightweight structure for rapid prototyping
    minimal = c("data", "scripts", "output", "possessdata")
  )

  # --- 2. Logic Parsing: Preset vs. Custom ---
  target_dirs <- if (is.list(structure) || (is.character(structure) && length(structure) > 1)) {
    structure
  } else if (structure %in% names(preset_schemes)) {
    preset_schemes[[structure]]
  } else {
    stop("❌ Error: 'structure' must be 'standard', 'minimal', or a custom character vector.")
  }

  # --- 3. Execute Directory Creation ---
  root <- if (is.null(project_name)) getwd() else project_name
  if (!dir.exists(root)) dir.create(root, recursive = TRUE)

  cat(sprintf("🏗️  GrandR Scaffold: Initializing project workspace [%s]...\n", basename(root)))

  for (d in target_dirs) {
    path <- file.path(root, d)
    if (!dir.exists(path)) {
      dir.create(path, recursive = TRUE)
      cat(sprintf("  [Create] %s\n", d))
    }
  }

  # --- 4. Generate Environment Bootstrapper (init.R) ---
  init_file <- file.path(root, "init.R")
  init_content <- c(
    "# ================================================",
    sprintf("# Project: %s", basename(root)),
    sprintf("# Author:  %s", author),
    sprintf("# Date:    %s", Sys.Date()),
    "# ================================================",
    "",
    "library(GrandR)",
    "library(tidyverse)",
    "library(patchwork)",
    "",
    "# --- 📂 Global Path Configuration ---",
    if ("data/processed" %in% target_dirs) "PATH_DATA <- 'data/processed/'" else "",
    if ("figures/raw" %in% target_dirs) "PATH_FIG  <- 'figures/raw/'" else "",
    "PATH_ARCHIVE <- 'possessdata/'",
    "",
    "# --- 🎨 Global Palette Themes ---",
    "# Set your primary colors for the project here",
    "GR_pal_set(PIM1_Mut='#E64B35', PIM1_WT='#4DBBD5', theme_id='Main')",
    "",
    "# --- 🛰️  GrandR Commands ---",
    "# GR_view_indexer()  # Use this to view all experiment records",
    "# GR_vault_explorer() # Use this to scan your data assets",
    "",
    "message('✅ GrandR Environment loaded successfully. Happy coding!')"
  )
  writeLines(init_content, init_file)

  cat(sprintf("\n🚀 Scaffold complete!\nRun `setwd('%s')` and `source('init.R')` to begin your analysis.\n", root))
}
